export const partySize = [
    {
        value: 1,
        label: "1 person"
    },
    {
        value: 2,
        label: "2 people"
    },
    {
        value: 3,
        label: "3 people"
    },
    {
        value: 4,
        label: "4 people"
    },
    {
        value: 5,
        label: "5 people"
    },
    {
        value: 6,
        label: "6 people"
    },
    {
        value: 7,
        label: "7 people"
    },
    {
        value: 8,
        label: "8 people"
    },
    {
        value: 9,
        label: "9 people"
    },
    {
        value: 10,
        label: "10 people"
    }
]